#ifndef ANIMATION_H
#define ANIMATION_H

#include<SFML/Graphics.hpp>

class Animation
{
    public:
        Animation();
        ~Animation();

        void Initialize(float x, float y, int FrameX, int FrameY);
        void Update(sf::RenderWindow &Window);
        void Draw(sf::RenderWindow &Window);

        bool getActive();
        void setActive(bool active);

        int getCurrentFrame(int axis);
        void setCurrentFrame(int axis, int value);

        float getPosition(int axis);
        void setPosition(int axis, int value);

        void setImage(sf::Image &tempImage);
    protected:
        int getFrameWidth();
        int getFrameHeight();
    private:
        sf::Sprite spriteImage;
        int currentFrameX, currentFrameY;
        float x, y;
        float frameCounter, switchFrame;
        int amountOfFramesX, amountOfFramesY;
        bool active;

        sf::Clock Clock;
};

#endif // ANIMATION_H
