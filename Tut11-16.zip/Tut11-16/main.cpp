#include<SFML/Graphics.hpp>

#include "Player.h"
#include "Camera.h"
#include "Global.h"
#include <ctime>

int main()
{
    sf::RenderWindow Window (sf::VideoMode(ScreenWidth, ScreenHeight, 32), "CodingMadeEasy SpriteSheet");

    Player player;
    Camera camera;

    player.Initialize();
    player.LoadContent();

    camera.Initialize();

    sf::Image backgroundImage;
    sf::Sprite backgroundSprite;

    if(backgroundImage.LoadFromFile("background.png"))
        backgroundSprite.SetImage(backgroundImage);

    while(Window.IsOpened())
    {
        sf::Event Event;
        while(Window.GetEvent(Event))
        {
            if(Event.Type == sf::Event::Closed || Event.Key.Code == sf::Key::Escape)
                Window.Close();
        }
        player.Update(Window);
        camera.Update(player.getX(), player.getY());

        Window.Clear();
        Window.Draw(backgroundSprite);
        player.Draw(Window);
        Window.Display();
    }
    return 0;
}
