#include "Camera.h"

Camera::Camera()
{
    //ctor
}

Camera::~Camera()
{
    //dtor
}

void Camera::Initialize()
{
    cameraX = cameraY = 0;
}

void Camera::Update(int x, int y)
{
    cameraX = -(ScreenWidth / 2) + x;
    cameraY = -(ScreenHeight / 2) + y;

    if(cameraX < 0)
        cameraX = 0;
    if(cameraY < 0)
        cameraY = 0;

    CameraPosition.SetFromRect(sf::FloatRect(cameraX, cameraY, cameraX + ScreenWidth, cameraY + ScreenHeight));
}

void Camera::Draw(sf::RenderWindow &Window)
{
    Window.SetView(CameraPosition);
}

void Camera::SetView(sf::View Camera)
{
    this->CameraPosition = Camera;
}

sf::View Camera::getView()
{
    return CameraPosition;
}
