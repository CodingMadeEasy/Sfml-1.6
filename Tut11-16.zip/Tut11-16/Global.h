#define ScreenWidth 800
#define ScreenHeight 600
