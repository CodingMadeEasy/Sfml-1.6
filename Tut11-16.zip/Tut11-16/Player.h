#ifndef PLAYER_H
#define PLAYER_H

#include<SFML/Graphics.hpp>
#include"Animation.h"
#include"Camera.h"

class Player
{
    public:
        Player();
        ~Player();

        void Initialize();
        void LoadContent();
        void Update(sf::RenderWindow &Window);
        void Draw(sf::RenderWindow &window);

        float getX();
        float getY();
    protected:
        Animation playerAnimation;
        Camera camera;
    private:
        sf::Image playerImage;
        float x, y;
        int currentFrameX, currentFrameY;
        float moveSpeed;
};

#endif // PLAYER_H
