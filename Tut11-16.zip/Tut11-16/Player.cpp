#include "Player.h"

Player::Player()
{
    //ctor
}

Player::~Player()
{
    //dtor
}

void Player::Initialize()
{
    x = y = 10;
    moveSpeed = 200;
    currentFrameX = currentFrameY = 0;
    playerAnimation.Initialize(x, y, 4, 4);
    camera.Initialize();
}

void Player::LoadContent()
{
    if(playerImage.LoadFromFile("Player.png"))
        playerAnimation.setImage(playerImage);
}

void Player::Update(sf::RenderWindow &Window)
{
    playerAnimation.setActive(true);

    if(Window.GetInput().IsKeyDown(sf::Key::W))
    {
        sf::View tempView = camera.getView();
        tempView.Zoom(2.0f);
        camera.SetView(tempView);
    }
    else if(Window.GetInput().IsKeyDown(sf::Key::S))
    {
        sf::View tempView = camera.getView();
        tempView.Zoom(-0.1);
        camera.SetView(tempView);
    }

    if(Window.GetInput().IsKeyDown(sf::Key::Right))
    {
        x += moveSpeed * Window.GetFrameTime();
        currentFrameY = 2;
    }
    else if(Window.GetInput().IsKeyDown(sf::Key::Left))
    {
        x -= moveSpeed * Window.GetFrameTime();
        currentFrameY = 1;
    }
    else if(Window.GetInput().IsKeyDown(sf::Key::Up))
    {
        y -= moveSpeed * Window.GetFrameTime();
        currentFrameY = 3;
    }
    else if(Window.GetInput().IsKeyDown(sf::Key::Down))
    {
        y += moveSpeed * Window.GetFrameTime();
        currentFrameY = 0;
    }
    else
        playerAnimation.setActive(false);

    playerAnimation.setPosition(1, x);
    playerAnimation.setPosition(2, y);
    playerAnimation.setCurrentFrame(2, currentFrameY);
    playerAnimation.Update(Window);
    camera.Update(x, y);
}

void Player::Draw(sf::RenderWindow &Window)
{
    camera.Draw(Window);
    playerAnimation.Draw(Window);
}

float Player::getX()
{
    return x;
}

float Player::getY()
{
    return y;
}

